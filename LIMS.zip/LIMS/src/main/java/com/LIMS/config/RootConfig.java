package com.LIMS.config;

import java.util.Properties;

import javax.sql.DataSource;
 
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
//Config data is coming from db.properties which is in class path
@PropertySource("classpath:db.properties")
@EnableTransactionManagement
@ComponentScan(basePackages =
			{
			"com.LIMS.model", 
			"com.LIMS.config",
			"com.LIMS.controller",
			"com.LIMS.service",
			"com.LIMS.dao"
			}
		)

public class RootConfig 
{
	
	@Autowired
	private Environment env;
	LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
	    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
	    sessionFactory.setDataSource(dataSource());
	    sessionFactory.setHibernateProperties(hibernateProperties());
	    sessionFactory.setPackagesToScan(new String[] { "com.LIMS.model" });
	    
	    return sessionFactory;
	 }
 
	@Bean
	public DataSource dataSource() 
	{
	    DriverManagerDataSource dataSource = new DriverManagerDataSource();
	    dataSource.setDriverClassName(env.getRequiredProperty("postgres.driver"));
	    dataSource.setUrl(env.getRequiredProperty("postgres.url"));
	    dataSource.setUsername(env.getRequiredProperty("postgres.username"));
	    dataSource.setPassword(env.getRequiredProperty("postgres.password"));
	    return dataSource;
	}
	
	 private Properties hibernateProperties() 
	 {
	        Properties properties = new Properties();
	        properties.put("hibernate.dialect", env.getRequiredProperty("hibernate.dialect"));
	        properties.put("hibernate.show_sql", env.getRequiredProperty("hibernate.show_sql"));
	        properties.put("hibernate.hbm2ddl.auto", env.getRequiredProperty("hibernate.hbm2ddl.auto"));
	        properties.put("hibernate.format_sql", env.getRequiredProperty("hibernate.format_sql"));
	        properties.put("hibernate.temp.use_jdbc_metadata_defaults", env.getRequiredProperty("hibernate.temp.use_jdbc_metadata_defaults"));
	        return properties;        
	 }
	     
	 @Bean
	 @Autowired
	 public HibernateTransactionManager transactionManager(SessionFactory s) 
	 {
	       HibernateTransactionManager txManager = new HibernateTransactionManager();
	       txManager.setSessionFactory(s);
	       return txManager;
	 }
 }
 