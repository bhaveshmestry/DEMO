package com.LIMS.controller;

	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
	import java.time.format.DateTimeFormatter;
	import java.time.format.FormatStyle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
	import org.springframework.ui.Model;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;

import com.LIMS.dao.ILIMSDao;
import com.LIMS.model.LIMSTable;
import com.LIMS.service.ILIMSService;
import com.LIMS.service.LIMSService;

	
	@Controller
	public class LIMSController 
	{
	   
	@Autowired
	ILIMSService service;
	LIMSTable value = new LIMSTable();
		
	  /* @RequestMapping(path={"/"},method=RequestMethod.GET)
	   public String sayHello(Model model) {
			try 
			{
		        Class.forName("org.postgresql.Driver");
		        Connection c = DriverManager.getConnection(
		        		ILIMSDao.HOST+ILIMSDao.DB_NAME,
		        		ILIMSDao.USERNAME,
		        		ILIMSDao.PASSWORD);
		         
		        System.out.println("DB connected");
		    }
			catch (ClassNotFoundException | SQLException e) 
			{
		        e.printStackTrace();
		    }
			
			
			value.setBkAuthor("Bhavesh");
			value.setBkTitle("My Book");
			service.enterData(value);
			
			
	      return "index";
	   }*/
	
	  
	}


