package com.LIMS.dao;

import com.LIMS.model.LIMSTable;

public interface ILIMSDao {
	 public static final String HOST = "jdbc:postgresql://localhost:5432/";
	    public static final String DB_NAME = "postgres";
	    public static final String USERNAME = "postgres";
	    public static final String PASSWORD = "root";
	    

		public void enterData(LIMSTable value);
}
