package com.LIMS.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.SessionFactory;
import org.postgresql.core.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.LIMS.model.LIMSTable;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao
{
	@Autowired
	private SessionFactory sessionFactory;
	

	@Override
	public void enterData(LIMSTable value) {
		System.out.println("Working Properly................................................");
		System.out.println(value.getBkId());
		System.out.println(value.getBkAuthor());
		System.out.println(value.getBkTitle());
		
		EntityManager entitymanager = sessionFactory.createEntityManager();
		entitymanager.getTransaction().begin();
		entitymanager.persist(value);
		entitymanager.getTransaction().commit();
		
		List<LIMSTable> list = entitymanager.createQuery("Select l from LIMSTable l").getResultList();
		
		System.out.println("1 row inserted");
		
		entitymanager.clear();
		entitymanager.close();
		
	}
	

}
