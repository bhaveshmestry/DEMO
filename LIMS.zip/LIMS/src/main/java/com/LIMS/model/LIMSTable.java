package com.LIMS.model;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Component
@Entity(name="LIMSTable")
public class LIMSTable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int bkId;
	private String bkTitle;
	private String bkAuthor;
	
	
	public int getBkId() {
		return bkId;
	}
	public void setBkId(int bkId) {
		this.bkId = bkId;
	}
	public String getBkTitle() {
		return bkTitle;
	}
	public void setBkTitle(String bkTitle) {
		this.bkTitle = bkTitle;
	}
	public String getBkAuthor() {
		return bkAuthor;
	}
	public void setBkAuthor(String bkAuthor) {
		this.bkAuthor = bkAuthor;
	}
	
	

}
