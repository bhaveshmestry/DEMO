package com.LIMS.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LIMS.dao.ILIMSDao;
import com.LIMS.dao.LIMSDao;
import com.LIMS.model.LIMSTable;

@Service
public class LIMSService implements ILIMSService{

	@Autowired
	ILIMSDao dao;

	@Override
	public void enterData(LIMSTable value) {
		// TODO Auto-generated method stub
		System.out.println("Working Properly in Service");
		System.out.println(value.getBkId());
		dao.enterData(value);
	}
	
}
