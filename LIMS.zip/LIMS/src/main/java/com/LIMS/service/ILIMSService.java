package com.LIMS.service;

import com.LIMS.model.LIMSTable;

public interface ILIMSService {

	public void enterData(LIMSTable value);
	
}
